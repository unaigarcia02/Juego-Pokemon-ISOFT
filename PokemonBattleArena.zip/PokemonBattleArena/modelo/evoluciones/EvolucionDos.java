package modelo.evoluciones;

public class EvolucionDos implements Evoluciones{
	
	private int ataque = 7;
	private int defensa = 5;
	private int evolucion = 2;

	public EvolucionDos() {
		// TODO Auto-generated constructor stub
	}

	public int bonoAtaque() {
		// TODO Auto-generated method stub
		return this.ataque;
	}

	public int bonoDefensa() {
		// TODO Auto-generated method stub
		return this.defensa;
	}

	public int evolucion() {
		// TODO Auto-generated method stub
		return this.evolucion;
	}

}
