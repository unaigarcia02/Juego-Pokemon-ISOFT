package modelo;

public enum Tipo {
	FUEGO, AGUA, ELECTRICO, PLANTA;
}
