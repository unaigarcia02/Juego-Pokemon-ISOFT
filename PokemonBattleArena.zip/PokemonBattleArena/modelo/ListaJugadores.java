package modelo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class ListaJugadores {
	private static ListaJugadores listaJugadores = null;
	private List<Jugador> lista;
	
	private ListaJugadores() {
		this.lista = new ArrayList<>();
	}
	
	public static ListaJugadores getListaJugadores() {
		if(listaJugadores == null) {
			listaJugadores = new ListaJugadores();
		}
		return listaJugadores;
	}
	
	public void crearJugadores(int pNumJugadores, int pNumBots, int pNumPokemons){
		for(int i = 0;i<pNumJugadores; i++) {
			Jugador jugador = new Jugador(pNumPokemons);
			this.anadirJugador(jugador);;
		}
		for(int j = 0;j<pNumBots; j++) {
			Bot bot = new Bot(pNumPokemons);
			this.anadirJugador(bot);
		}
	}
	
	public void anadirJugador(Jugador pJugador) {
		this.lista.add(pJugador);
	}
	
	public void eliminarJugador(Jugador pJugador) {
		this.lista.remove(pJugador);
	}
	
	public Jugador getJugadorPos(int pPos) {
		return (Jugador) this.lista.get(pPos);
	}
	public int tamañoLista(){
		return this.lista.size();
	}
	public Jugador getJugadorPorNombre(String pNombre) {
		Iterator<Jugador> it = this.iterator();
		boolean encontrado = false;
		Jugador j = null;
		while(it.hasNext() && !encontrado) {
			j = it.next();
			if(j.getNombre().equals(pNombre)) {
				encontrado = true;
			}
		}
		return j;
	}
	public Jugador getJugadorAleatorio(Jugador pJugador) {
		boolean encontrado = false;
		Jugador j = null;
		while(!encontrado) {
			Random random = new Random();
			j = ListaJugadores.getListaJugadores().getJugadorPos(random.nextInt(ListaJugadores.getListaJugadores().tamañoLista()));
			if(!j.equals(pJugador)) {
				encontrado = true;
			}
		}
		return j;
	}
	private Iterator<Jugador> iterator(){
		return this.lista.iterator();
	}
	
	public Jugador getJugadorConTurno() {
		Jugador jugador = null;
		for(Jugador j : this.lista) {
			if(j.getTurno() == true) {
				jugador = j;
			}
		}
		return jugador;
	}
}




