package modelo;


import vista.PantallaPrincipal;

public class ProgramaPrincipal {
	
	public static void main(String[] args) {
		PantallaPrincipal.getPantallaPrincipal();
	}
}
