package modelo;

import java.util.Observable;


@SuppressWarnings("deprecation")
public class Juego extends Observable{
	private static Juego juego = null;
	
	public Juego() {
		
	}
	
	public static Juego getJuego() {
		if(juego == null) {
			juego = new Juego();
		}
		return juego;
	}
	
	public void iniciarPartida(int numJugadores, int numBots, int miliSeg, int numPokemons) {
		int i = 0;
		ListaJugadores.getListaJugadores().crearJugadores(numJugadores, numBots, numPokemons);
		while(i<ListaJugadores.getListaJugadores().tamañoLista()) {
			this.setChanged();
			this.notifyObservers(new Object[] {i, ListaJugadores.getListaJugadores().getJugadorPos(i).getNombre(), numPokemons});
			i++;
		}
		Batalla.getBatalla().asignarTurno();
	}
	
}