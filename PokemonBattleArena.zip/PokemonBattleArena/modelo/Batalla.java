package modelo;

import java.util.Random;

import javax.swing.JOptionPane;

public class Batalla {
	private static Batalla pBatalla = null;
	private Jugador jugadorAtacante;
	private Jugador jugadorDefensor;
	private Pokemon pokemonAtacante;
	private Pokemon pokemonDefensor;
	private Random random = new Random();
	
	public static Batalla getBatalla() {
		if(pBatalla == null) {
			pBatalla = new Batalla();
		}
		return pBatalla;
	}

	public void setJugadorAtacante(Jugador pJugador) {
		this.jugadorAtacante = pJugador;
	}
	public void setJugadorDefensor(Jugador pJugador) {
		this.jugadorDefensor = pJugador;
	}
	public void setPokemonatacante(Pokemon pPokemon) {
		this.pokemonAtacante = pPokemon;
	}
	public void setPokemonDefensor(Pokemon pPokemon) {
		this.pokemonDefensor = pPokemon;
	}
	public Pokemon getPokemonAtacante() {
		return this.pokemonAtacante;
	}
	public Pokemon getPokemonDefensor() {
		return this.pokemonDefensor;
	}
	
	public void reiniciar() {
		this.jugadorAtacante = null;
		this.jugadorDefensor = null;
		this.pokemonAtacante = null;
		this.pokemonDefensor = null;
	}

	public void asignarTurno() {
		for(int a = 0; a < ListaJugadores.getListaJugadores().tamañoLista(); a++) {
			this.eliminarJugador(ListaJugadores.getListaJugadores().getJugadorPos(a));
		}
		this.mostrarMensaje();
		if(ListaJugadores.getListaJugadores().tamañoLista() >= 2) {
			int i = random.nextInt(ListaJugadores.getListaJugadores().tamañoLista());
			for(int j = 0; j<ListaJugadores.getListaJugadores().tamañoLista();j++) {
				if(ListaJugadores.getListaJugadores().getJugadorPos(j) != ListaJugadores.getListaJugadores().getJugadorPos(i)) {
					ListaJugadores.getListaJugadores().getJugadorPos(j).setTurno(false);
				}
				else {
					ListaJugadores.getListaJugadores().getJugadorPos(i).setTurno(true);
					ListaJugadores.getListaJugadores().getJugadorPos(i).jugarTurno();
					for(int x = 0; x<ListaJugadores.getListaJugadores().getJugadorPos(i).getListaPokemons().size();x++) {
						ListaJugadores.getListaJugadores().getJugadorPos(i).getListaPokemons().get(x).reiniciarAtaque();
					}
				}
			}
		}
	}
	
	public boolean atacar() {
		boolean correcto = true;
		if(pokemonAtacante != null && pokemonAtacante.getDerrotado() == false && pokemonDefensor != null  && pokemonDefensor.getDerrotado() == false && this.jugadorAtacante != null && this.jugadorDefensor != null && correcto && this.pokemonAtacante.yaHaAtacado() == false) {
			pokemonDefensor.recibirAtaque(pokemonAtacante.getAtaque(), pokemonAtacante.getTipo(), pokemonAtacante.getEvo());
			this.pokemonAtacante.quitarEuforia();
			this.pokemonAtacante.ataqueHecho(true);
			this.reiniciar();
			correcto = true;
		}
		else {
			correcto = false;
		}
		
		return correcto;
	}
	
	public boolean terminarPartida() {
		boolean terminar;
		if(ListaJugadores.getListaJugadores().tamañoLista() == 1) {
			terminar = true;
		}
		else {
			terminar = false;
		}
		return terminar;
	}
	
	public void mostrarMensaje() {
		if(ListaJugadores.getListaJugadores().tamañoLista() < 2) {
			JOptionPane.showMessageDialog(null, "El ganador es: " + ListaJugadores.getListaJugadores().getJugadorPos(0).getNombre());
		}
	}
	
	public void eliminarJugador(Jugador pJugador) {
		if(pJugador.todosDerrotados()) {
			ListaJugadores.getListaJugadores().eliminarJugador(pJugador);
		}
	}
}

